/**
 * Module:  module_uart_1thread
 * Version: 1v1
 * Build:   9c58ca3d12d5e8b3c1da0e1ce6fbbd76fa9f316d
 * File:    uart_1thread.h
 *
 * The copyrights, all other intellectual and industrial 
 * property rights are retained by XMOS and/or its licensors. 
 * Terms and conditions covering the use of this code can
 * be found in the Xmos End User License Agreement.
 *
 * Copyright XMOS Ltd 2010
 *
 * In the case where this code is a modification of existing code
 * under a separate license, the separate license terms are shown
 * below. The modifications to the code are still covered by the 
 * copyright notice above.
 *
 **/                                   
#ifndef _uart_h_
#define _uart_h_
#include <xs1.h>

#ifndef UART_BIT_RATE
#define UART_BIT_RATE 115200 // e.g. 9600, 38400, 115200, 460800
#endif

#define UART_BIT_TIME   (XS1_TIMER_HZ / UART_BIT_RATE)
#define SAMPLES_PER_BIT 3
#define SAMPLE_DELAY    (UART_BIT_TIME / SAMPLES_PER_BIT)

// Rxd State machine
#define RXD_STATE_WAIT_FOR_START  0
#define RXD_STATE_START_DETECTED  1
#define RXD_STATE_BIT0            2
#define RXD_STATE_BIT1            (RXD_STATE_BIT0 + 1)
#define RXD_STATE_BIT2            (RXD_STATE_BIT0 + 2)
#define RXD_STATE_BIT3            (RXD_STATE_BIT0 + 3)
#define RXD_STATE_BIT4            (RXD_STATE_BIT0 + 4)
#define RXD_STATE_BIT5            (RXD_STATE_BIT0 + 5)
#define RXD_STATE_BIT6            (RXD_STATE_BIT0 + 6)
#define RXD_STATE_BIT7            (RXD_STATE_BIT0 + 7)
#define RXD_STATE_STOP            (RXD_STATE_BIT0 + 8)
#define RXD_STATE_INVALID_STOP    99

/********************************************************************/
/* BASIC UART I/O Function                                          */
/********************************************************************/

void uart_1thread (port TXD, chanend txData_chan, port RXD, chanend rxData_chan);

#endif
