#ifndef BLINKALLPINS_H_
#define BLINKALLPINS_H_

#define FREQ 3						// in Hz
#define DELAY (99937500>>1)/FREQ	// DELAY = (99937500Hz/2)/FREQ

#define STATE_S 0
#define STATE_B	1
#define STATE_P	2

#define NUM_SETS 14					// number of sets in pin_set_array[]
#define LAST_SET_INDEX NUM_SETS - 1	// index of the last set in pin_set_arrayp[]

typedef struct _pin_set {
	unsigned portToBlink;
	char startPin;
	char stopPin;
} pin_set;

void blink_all_pins(chanend rxDataBlink_ch);

char blink_pin(pin_set &pset);

#endif /* BLINKALLPINS_H_ */
